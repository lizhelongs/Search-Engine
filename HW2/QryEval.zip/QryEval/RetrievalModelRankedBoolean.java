public class RetrievalModelRankedBoolean extends RetrievalModel {

    public String defaultQrySopName () {
        return new String ("#and");
    }

}